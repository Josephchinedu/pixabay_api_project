<?php
ob_start();
  include("geoiploc.php"); // Must include this
  $ip = $_SERVER["REMOTE_ADDR"];
  $country= getCountryFromIP($ip);

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<meta name="author" content="">
	<title>Fixed Matches</title>
	<!-- custom css -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<!-- font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
<style>.blink {
  animation: blinker 1s step-start infinite;
}

@keyframes blinker {
  50% {
    opacity: 0;
  }
}</style>
<body>
	<header>
 		<div id="top-btn">
 			<a href="https://t.me/joinchat/MGzGIEZCruUt25IdXItl8g"><img src='img/join-our-telegram-channel.png' width='300px'></a>
			
 		</div>
		<nav class="navbar navbar-expand-lg navbar-dark">
			<div class="container">
				<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsibleNavbar">
					<span class="navbar-toggler-icon"></span>
				</button>
				<a href="index.html" class="nav-brand" id="brand">Accurate Fixed <span id="mt">Match</span></a>
			</div>
		</nav>
	</header>

	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<nav class="navbar navbar-expand-lg navbar-dark" id="menu">
						<div id="collapsibleNavbar" class="collapse navbar-collapse">
							<ul class="navbar-nav m-auto">
								<li class="nav-item">
									<a href="/" class="nav-link">Home</a>
								</li>
							<a href="login.php"><button type="button" class="btn bg-danger text-white btn-sm" style='font-size:18px'>Enter Vip Member Area</button></a>
		
							</ul>
						</div>
					</nav>
				</div>
			</div>
		</div>
	</section>


	<!-- body content -->
	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="main-body">
						<div class="jumbotron" id="about-us">
							<div class="row">
								<div class="col-md-6">
									<p>We have made a team of professionals from the world-class coating Fixed Match is fully dedicated to providing superior results for our clients, and our guarantee allows your guaranteed profits.</p>
									<p><span>accuratefixedmatch.com</span> offers a chance for giving best advices and suggestions for betting on real betting fixed matches.</p>
									<p>We want to help you make more money just like all of the other people who enjoy betting.</p>
									<p><span>Accurate Fixed Match</span> TIPS IS THE BEST SITE FOR MAKING GUARANTEE PROFIT.</p>
									<p><span>BECOME OUR MEMBERS AND EXPERIENCE THE BEST GAMBLING RUSH.</span><p>

									<p>Our sources are max reliable and they are giving to us the best information for real fixed matches 100% safe.
									<span>BECOME RICH AND HAVE FUN.</span></p><br><br>



									<div id="advert">
										<img src="img/under-18-no-admit.png" id="a18">
										
									</div>
								</div>

								<div class="col-md-6">
									<h4 class="text-center">Recent Winnings</h4>
									<div class="row" style="margin-top: 10px;">
										<div class="col-md-6">
											<table class="table table-bordered" style="background-color: #007bff; color: #fff;" id="recent-win">
												<thead>
													<tr>
														<td>Date</td>
														<td>Odd</td>
														<td>Result</td>
													</tr>
												</thead>

												<tbody>
												     <tr>
														<td>09.09.2019</td>
														<td>27.50</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
												     <tr>
														<td>07.09.2019</td>
														<td>100.58</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
												     <tr>
														<td>06.09.2019</td>
														<td>168.00</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
												    <tr>
														<td>30.08.2019</td>
														<td>34.00</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
												     <tr>
														<td>28.08.2019</td>
														<td>154.74</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
												    <tr>
														<td>26.08.2019</td>
														<td>74.00</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
												    
												    
												    
												

												
												
												
												</tbody>
											</table>

											<img src="img/d.png" style="max-width: 100%"><br><br>
										
										</div>


										<div class="col-md-6">
											<table class="table table-bordered" style="background-color: purple; color: #fff; " id="recent-win">
												<thead>
												    
													<tr>
														<td>Date</td>
														<td>Odd</td>
														<td>Result</td>
													</tr>
												</thead>

												<tbody>	
												<tr>
														<td>25.08.2019</td>
														<td>22.70</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
												 <tr>
														<td>24.08.2019</td>
														<td>600.00</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
													<tr>
														<td>23.08.2019</td>
														<td>58.23</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
													
												<tr>
														<td>22.08.2019</td>
														<td>101.75</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
													<tr>
														<td> 20.08.2019</td>
														<td>61.00</td>
														<td><i class="fa fa-check"></i></td>
													</tr>
												
												
												<tr>
														<td>19.08.2019</td>
														<td>38.00</td>
														<td ><i class="fa fa-check" ></i></td>
													</tr>
												    
												   
												    
													
												

													
													
													
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>


					



						<div class="jumbotron">
						   <center><img class="alignnone wp-image-8303" src="http://tips-free.com/wp-content/uploads/2019/02/ht0Kxyi-1.png" sizes="(max-width: 400px) 100vw, 400px" srcset="http://tips-free.com/wp-content/uploads/2019/02/ht0Kxyi-1.png 492w, http://tips-free.com/wp-content/uploads/2019/02/ht0Kxyi-1-300x75.png 300w" alt="" width="400" height="100"></center> 
<p style="text-align: center;"><span style="color: #000000; font-size: 14pt; font-family: verdana, geneva, sans-serif;"><strong>DATE: 12.09.2019 (Wednesday)</strong></span></p>
<p style="text-align: center;"><span style="color: #000000; font-size: 14pt; font-family: verdana, geneva, sans-serif;"><strong>NUMBER OF MATCHES: 3 Correct Score</strong></span></p>
<p style="text-align: center;"><span style="color: #000000; font-size: 14pt; font-family: verdana, geneva, sans-serif;"><strong>PICKS: X-1, X-2, X-X, 1-1, 2-2</strong></span></p>
<p style="text-align: center;"><span style="color: #000000; font-size: 14pt; font-family: verdana, geneva, sans-serif;"><strong>TOTAL ODD: 100.00 – 700.00</strong></span></p>
<p style="text-align: center;" class='blink'><span style="color: #b20; font-size: 14pt; font-family: verdana, geneva, sans-serif;"><strong>PRICE: <?php if($country=="NG"){?>
  N30,000 - <span style='color:green;font-size:14px'>Your Country Nigeria</span> 
<?php }elseif($country=="KE" || $country=="UG" || $country=="TZ"){?>
20000 Kes 
<?php }elseif($country=="GH"){?>
500 GHs
<?php }else{ ?>
$100
<?php }?> </strong></span></p>

<p style="text-align: center; ">***<span style="color:#f60;  text-decoration: line-through;font-size: 14pt; font-family: verdana, geneva, sans-serif;"><strong>test or payment after win will be ignored !</strong></span></p>
<p>&nbsp;</p><br>
							<h4 class="text-center" style="font-size: 39px;">Pricing</h4>
							<div class="row">
							    	<div class="col-md-3 text-center">
									<div id="one-week" >
										<table class="table table-bordered" style='background:green'>
											<thead>
												<tr>
													<td> Fixo Vip / week</td>
												</tr>
											</thead>

											<tbody>
												<tr>
													<td class='blink' ><?php if($country=="NG"){?>
  N10,000 - <span style='color:purple;font-size:14px'>Your Country Nigeria</span> 
<?php }elseif($country=="KE" || $country=="UG" || $country=="TZ"){?>
5000 Kes 
<?php }elseif($country=="GH"){?>
300 GHs
<?php }else{ ?>
$85
<?php }?></td>
												</tr>
												<tr>
													<td>Sure 2 - 20</td>
												</tr>
												<tr>
													<td>3 matches daily</td>
												</tr>
												<tr>
													<td>100% sure</td>
												</tr>
												<tr>
												    <td>
												        
												    <h5>Pay With</h5>
							
							 <a href='https://blockchain.com/btc/payment_request?address=14CQvUKvNkhCTyix3o7XDyb968XGqRSrfw&amount=0.00822255&message=3 Days fixed Match Plan'> <img src="img/Bitcoin-Accepted-3x1-2-1.jpg" width='80px'>
							 </a>
						<br><br>
							
							<a href='https://rave.flutterwave.com/pay/accuratefixedk9hu'> <img src="https://www.scsglobalservices.com/files/images/payments/4_Card_color_horizontal.png" width='100%'>
							 </a><br><br>
						      <?php if($country=="NG"){?>
						      	<a href='' class='btn btn-primary' data-toggle="modal" data-target="#mybank" style='margin-left:10px;'> Pay to local bank in Nigeria</a>
						      <? } ?>
							
								<a href='' data-toggle="modal" data-target="#myModal" style='margin-left:10px;'> <img src="https://account.skrill.com/wallet/ng/assets/svg/skrill-logo.svg" width='80px'></a>
						</td>
												</tr>
											</tbody>
										</table>

									
									</div> 
								</div>

								<div class="col-md-3 text-center">
									<div id="one-week">
										<table class="table table-bordered">
											<thead>
												<tr>
													<td>Jumbo Vip / 2 weeks</td>
												</tr>
											</thead>

											<tbody>
												<tr>
													<td><?php if($country=="NG"){?>
  N18,000 - <span style='color:green;font-size:14px'>Your Country Nigeria</span> 
<?php }elseif($country=="KE" || $country=="UG" || $country=="TZ"){?>
10000 Kes 
<?php }elseif($country=="GH"){?>
500 GHs
<?php }else{ ?>
$180
<?php }?></td>
												</tr>
												<tr>
													<td>Sure 30 - 80 odds</td>
												</tr>
												<tr>
													<td>3 - 5 matches daily</td>
												</tr>
												<tr>
													<td>100% sure</td>
												</tr>
												<tr>
												    <td>
												        
												    <h5>Pay With</h5>
							 <a href='https://blockchain.com/btc/payment_request?address=14CQvUKvNkhCTyix3o7XDyb968XGqRSrfw&amount=0.01808296&message=10 Days fixed Match Plan'> <img src="img/Bitcoin-Accepted-3x1-2-1.jpg" width='80px'>
							 </a>
							<br><br>
							
							<a href='https://rave.flutterwave.com/pay/accuratefixedk9hu'> <img src="https://www.scsglobalservices.com/files/images/payments/4_Card_color_horizontal.png" width='100%'>
							 </a><br>
						<br>
						 <?php if($country=="NG"){?>
						      	<a href='' class='btn btn-primary' data-toggle="modal" data-target="#mybank" style='margin-left:10px;'> Pay to local bank in Nigeria</a>
						      <? } ?>
							
								<a href='' data-toggle="modal" data-target="#myModal" style='margin-left:10px;'> <img src="https://account.skrill.com/wallet/ng/assets/svg/skrill-logo.svg" width='80px'></a>
						</td>
												</tr>
											</tbody>
										</table>

									
									</div> 
								</div>

								<div class="col-md-3 text-center">
									<div id="one-week">
										<table class="table table-bordered">
											<thead>
												<tr>
													<td>Pro Vip / Month</td>
												</tr>
											</thead>

											<tbody>
																				<tr>
													<td><?php if($country=="NG"){?>
  N30,000 - <span style='color:green;font-size:14px'>Your Country Nigeria</span> 
<?php }elseif($country=="KE" || $country=="UG" || $country=="TZ"){?>
20000 Kes 
<?php }elseif($country=="GH"){?>
700 GHs
<?php }else{ ?>
$300
<?php }?></td>
	<tr>
													<td>90 - 150 odds Daily</td>
												</tr>
												<tr>
													<td>3-5 matches Daily</td>
												</tr>
												<tr>
													<td>100% sure</td>
												</tr>
													<tr>
												    <td>
												        
												    <h5>Pay With</h5>
							 <a href='https://blockchain.com/btc/payment_request?address=1GEvKF1SebvWM6yvaxBwewLaSXaBVZQesZ&amount=0.03013827&message=25 Days FIxed Match'> <img src="img/Bitcoin-Accepted-3x1-2-1.jpg" width='80px'>
							 </a>
							
							<br><br>
							
							<a href='https://rave.flutterwave.com/pay/accuratefixedk9hu'> <img src="https://www.scsglobalservices.com/files/images/payments/4_Card_color_horizontal.png" width='100%'>
							 </a><br><br>
							 <?php if($country=="NG"){?>
						      	<a href='' class='btn btn-primary' data-toggle="modal" data-target="#mybank" style='margin-left:10px;'> Pay to local bank in Nigeria</a>
						      <? } ?>
								<a href='' data-toggle="modal" data-target="#myModal" style='margin-left:10px;'> <img src="https://account.skrill.com/wallet/ng/assets/svg/skrill-logo.svg" width='80px'></a>
						</td>
												</tr>
											</tbody>
										</table>

									
									</div> 
								</div>

								<div class="col-md-3 text-center">
									<div id="one-week">
										<table class="table table-bordered">
											<thead>
												<tr>
													<td>Vip Gold / 3 Months</td>
												</tr>
											</thead>

											<tbody>
																			<tr>
													<td><?php if($country=="NG"){?>
  N60,000 - <span style='color:green;font-size:14px'>Your Country Nigeria</span> 
<?php }elseif($country=="KE" || $country=="UG" || $country=="TZ"){?>
25000 Kes 
<?php }elseif($country=="GH"){?>
800 GHs
<?php }else{ ?>
$600
<?php }?></td>
	<tr>
											<td>sure 200 - 1000 odds daily</td>
												</tr>
												
												<tr>
													<td>3-5 matches daily</td>
												</tr>
												<tr>
													<td>100% sure</td>
												</tr>
													<tr>
												    <td>
												        
												    <h5>Pay With</h5>
							 <a href='https://blockchain.com/btc/payment_request?address=1GEvKF1SebvWM6yvaxBwewLaSXaBVZQesZ&amount=0.03013827&message=25 Days Fixed Match'> <img src="img/Bitcoin-Accepted-3x1-2-1.jpg" width='80px'>
							 </a><br><br>
							
							<a href='https://rave.flutterwave.com/pay/accuratefixedk9hu'> <img src="https://www.scsglobalservices.com/files/images/payments/4_Card_color_horizontal.png" width='100%'>
							 </a><br>
							<br> <?php if($country=="NG"){?>
						      	<a href='' class='btn btn-primary' data-toggle="modal" data-target="#mybank" style='margin-left:10px;'> Pay to local bank in Nigeria</a>
						      <? } ?>
								<a href=''data-toggle="modal" data-target="#myModal" style='margin-left:10px;'> <img src="https://account.skrill.com/wallet/ng/assets/svg/skrill-logo.svg" width='80px'></a>
						</td>
												</tr>
											</tbody>
										</table>

										
									</div> 
								</div>
							</div><br><br><br>


                           
<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Accurate Fixed match Payment Details</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <h3>Pay to Bitcoin <img src="img/Bitcoin-Accepted-3x1-2-1.jpg" width='50px'></h3><br><br>
       <p><span>Send To</span> 1H5aG2n8AanT6azzweFJzCe9vMuUcpf1rV</p>
       <hr><br><br>
       <h3>Pay to Skril <img src="https://account.skrill.com/wallet/ng/assets/svg/skrill-logo.svg" width=' 60px'></h3>
       <p><span>Send To</span> hello@accuratefixedmatch.com</p>
       <hr>
       <br><br>
       <h4>After Payment send your details to hello@accuratefixedmatch.com</h4>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<div class="modal" id="mybank">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Accurate Fixed match Payment Details</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <h3>Pay to FCMB <img src="https://www.fcmb.com/themes/fcmb/logo.png" width='50px'> Nigeria Only</h3><br><br>
       <p><h3 style='color:green'>Account Name: Flotila Services</h3></p>
       <hr><br>
       <h3 style='color:purple'>Account Number: 6360306016</h3>
      
       <hr>
       <br><br>
       <h4>After Payment send your details to hello@accuratefixedmatch.com</h4>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>




                                    
							<h4 class="text-center" style="font-size: 39px;">Payment Methods</h4>
							<center><div id="py-meth">
							    	
							<a href='https://rave.flutterwave.com/pay/accuratefixedk9hu'> <img src="https://www.scsglobalservices.com/files/images/payments/4_Card_color_horizontal.png" width='200px'>
							 </a> 
							 
								<img src="img/Bitcoin-Accepted-3x1-2-1.jpg" width='200px' data-toggle="modal" data-target="#myModal">
							
								<img src="https://account.skrill.com/wallet/ng/assets/svg/skrill-logo.svg" width='200px' data-toggle="modal" data-target="#myModal">
							</div></center>
							<br><br>

							<center><img src="img/THE-FIXED-OFFER.jpg"></center>


							<br>

							



						
							<!-- Advert -->

							<div id="py-meth">
								<img src="img/realmadrid-bet1x2-fixed-bet-tips-1x2-soccer-betting-tips-1x2.gif">
								<img src="img/real-soccer-matches-1.gif">
								<img src="img/okGFZKw.gif">
								<img src="img/l6E6i8K.gif">
							</div><br><br><br>


							<!-- Next Prediction -->
							<div class="row">
								<div class="col-md-10 offset-md-1" id="next">
									<h4 id="nex">NEXT HALF TIME FULL TIME FIXED MATCH</h4><br>
									<h3>20th September 2019</h3><br>
									<h3>MATCH:  — : —</h3><br>
									<h3>PICK: 2/1 (Half Time/Full Time)</h3><br>
									<h3>ODDS: 30.00</h3><br>
									<h3>SURE: <span class="text-danger">100%</span></h3>
								</div>
							</div> <br><br><br>

							<!-- Note -->
							<div id="about-us">
								<h2></h2> 

									<p><strong style="color: #d21e1f; font-size: 30px;">Note:</strong> Some of you try to be more clever and ask us to pay for the fixed match after they win.
									This is also something we can not do.
									First when we started this business, we tried this option. Can you imagine what they did? They created a new email account and contacted us again to get another fixed match to post pay it.
									If you want to get 100% REAL FIXED MATCH you must invest.

									</p>
							</div><br><br>


						</div>
						



						<!-- Footer -->
						<div style="background-color: #333; color: #fff; text-align: center;">
							All Rights Reserved &copy;
							<script type="text/javascript">
								var today = new Date();
								var yyyy = today.getFullYear();
								document.write(yyyy);
							</script>
							<center>
							    <span>Address</span> C/ Henan Cortes 78,Batres madrid Spain.
							    <br>
							    <h3>Contact us on hello@accuratefixedmatch.com</h3>
							</center>
							| 

							<a href="#" style="text-decoration: none; color: #d21e1f;">accuratefixedmatches.com</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>



<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d5f7f8feb1a6b0be608f40a/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/typed.min.js"></script>
	<script src="js/typed.js"></script>
	<script src="js/main.js"></script>
</body>
</html>