<?php
  ob_start();
  session_start();
  require("config.php");
?>
            
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="author" content="Joseph Chinedu">
	<title>Fixed Matches</title>
	<!-- custom css -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<!-- font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
<body>
	<header>
 		<div id="top-btn">
 		
 		</div>
		<nav class="navbar navbar-expand-lg navbar-dark">
			<div class="container">
				<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsibleNavbar">
					<span class="navbar-toggler-icon"></span>
				</button>
				<a href="index.html" class="nav-brand" id="brand">Accurate Fixed <span id="mt">Match</span></a>
			</div>
		</nav>
	</header>

	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<nav class="navbar navbar-expand-lg navbar-dark" id="menu">
						<div id="collapsibleNavbar" class="collapse navbar-collapse">
							<ul class="navbar-nav m-auto">
									<li class="nav-item">
									<a href="/" class="nav-link">Home</a>
								</li>
							<a href="login.php"><button type="button" class="btn bg-danger text-white btn-sm" style='font-size:18px'>Enter Vip Dashboard</button></a>
		
							</ul>
						</div>
					</nav>
				</div>
			</div>
		</div>
	</section>


	<!-- body content -->
	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="main-body">
						<div class="jumbotron" id="about-us">
						    	<?php
          
                if(isset($_POST["login"])){
                  $email = clean($_POST['email']);
                  $pass = clean($_POST['password']);

                  $result = mysqli_query($connection, "SELECT * FROM users WHERE email ='$email'");
                  
                  if(mysqli_num_rows($result) > 0)
                  { 
                    $rows = mysqli_fetch_assoc($result);
                    $hash = $rows['password'];
                    
                    if(crypt($pass, $hash) == $hash){
                      
                      $_SESSION["bast_email"] = $email;
                      $_SESSION["bast_password"] = $pass;
                      $_SESSION["member_id"] =  $rows["id"];
                      $_SESSION["bast_account"] = $rows["active_plan"];
                      
                     if($Dd != ''){
		                		header("Location: " . $Dd);
		                		exit();
		                	}else{
		                	    if($_GET['login']==1){
		                	        header("Location: viparea?login=1");
		                		exit();
		                	    }else{

		                		header("Location: viparea?login=1");
		                		exit();
		                	}
		                	}
                    
                    }else{
                        $alert="<div class='alert alert-warning'>Login failed. Incorrect Username or Password</div>";
                    
                    }
                  }else{ 
                      $alert="<div class='alert alert-danger'>Login failed. Incorrect Username or Password</div>";
                    ?>
                    
                
                    <?php
                  }
                }
              ?>
               <?php echo $alert ?>
							<div class="col-md-6 offset-md-3">
								<h4 class="text-center">Login into Vip Area</h4>
			
								<form class="form" action='' method='post'>
									<input type="email" name="email" placeholder="Email" class="form-control"><br>
									<input type="password" name="password" class="form-control" placeholder="Password"> <br>

									<button type='submit' name='login' class="btn bg-danger text-white" style='width:100%'>Login</button>
								</form>
								 <span class="type--fine-print block">Dont have an account yet?
                                <a href="new">Become VIP Member</a>
                            </span>
							
							</div>
							<br><br>
								<p> All we do is to help punters make consistent and daily profits from their various wagers and We always fulfill the expectations of admirers of Sport betting, you can start winning today..</p>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</section>





	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/typed.min.js"></script>
	<script src="js/typed.js"></script>
	<script src="js/main.js"></script>
	 <?php
  function clean($txt){
      
      return trim(htmlentities($txt));
  }
?>
</body>
</html>