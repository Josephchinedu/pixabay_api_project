
'use strict';

(function($) {
	$('.news-ticker').marquee({
	    duration: 10000,
	    delayBeforeStart: 0,
	    direction: 'left',
	    duplicated: true
	});



	$('.slider_img').owlCarousel({
		loop: true,
		nav: false,
		dots: true,
		mouseDrag: false,
		animateOut: 'fadeOut',
		animateIn: 'fadeIn',
		items: 1,
		autoplay: true
	});

	var dot = $('.slider_img .owl-dot');
	dot.each(function() {
		var index = $(this).index() + 1;
		if (index < 10){
			$(this).html('0').append(index);
			$(this).append('<span>.</span>');
		} else {
			$(this).html(index);
			$(this).append('<span>.</span>');
		}
	});



	$(".animated-text").typed({
        strings: [
            "Accurate Prediction",
            "Prediction Tips",
            "Well Accurate sure 2 odds"
        ],
        typeSpeed: 60,
        loop: true,
    });


    $(".animate-text").type({
        strings: [
            "Popular Matches"
        ],
        typeSpeed: 60,
        loop: true,
    });

})(jQuery);

