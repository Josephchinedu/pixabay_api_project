<?php
  
  ob_start();
  session_start();
  require("config.php");
 $ddate = date('Y-m-d H:i:s');
?>
<?php
    
    if(!isset($_SESSION["bast_email"]) && !isset($_SESSION["bast_password"]))
    {
        
           header("Location: /login?Dd=" . urlencode($_SERVER['REQUEST_URI']));
    }


  include("geoiploc.php"); // Must include this
  $ip = $_SERVER["REMOTE_ADDR"];
  $country= getCountryFromIP($ip);
$email= $_SESSION["bast_email"];

    $loginCheck=mysqli_query($connection,"INSERT INTO `login_check` (`email`, `status`, `new`, `ip`, `country`,  `ldate`) VALUES ( '$email', 'Online', '1', '$ip', '$country',  '$ddate')");
?>
       
<?php
  $query = "SELECT * FROM users WHERE email = '".$_SESSION['bast_email']."'";
  
  $sql = mysqli_query($connection,$query);

  $num_rows = mysqli_num_rows($sql);
    if($num_rows < 1) die($_SESSION['bast_email']);

    $fullName = "";
    $email = "";
    $country = "";
    $dateCreated = "";
    $active_plan = "";
    $active_from = "";
    $plan_expired = "";
    $vip_active = "";
    $vip_starts = "";
    $vip_expires = "";

    $row = mysqli_fetch_assoc($sql);
    $fullName = $row["fullName"];
    $email = $row["email"];
    $country = $row["country"];
    $dateCreated = $row["dateCreated"];
    $active_plan = $row["active_plan"];
    $active_from = $row["active_from"];
    $plan_expired = $row["plan_expired"];
    $vip_active = $row["vip_active"];
    $vip_starts = $row["vip_starts"];
    $period = $row["period"];
    $vperiod = $row["vperiod"];
    $vip_expires = $row["vip_expires"];
     $guided_active = $row["guided_active"];
    $guided_starts = $row["guided_starts"];
    $period = $row["period"];
    $speriod = $row["speriod"];
    $guided_ends = $row["guided_ends"];
  $vip_expires = $row["vip_expires"];
     $basket = $row["basket"];
    $basket_start = $row["basket_start"];
    $tperiod = $row["tperiod"];
    $bperiod = $row["bperiod"];
    $basket_ends = $row["basket_ends"];
     $tenins = $row["tenins"];
    $tenins_start = $row["tenins_start"];
    $tenins_ends = $row["tenins_ends"];
       $jackpot = $row["jackpot"];
    $jack_start = $row["jack_start"];
    $jack_ends = $row["jack_ends"];
    $jperiod = $row["Jperiod"];

    $today = date("Y-m-d", time());
    # Checks to see if the Basic or Premium Plan has expired or not.
    if($today > $plan_expired){

      $update_plan = mysqli_query($connection,"UPDATE users SET active_plan = '0', period = 'Free Forever'  WHERE email = '$email'");
      
      
    }

    #Checks to see if the Monster Tips Plan has expired or not.
    if($today > $vip_expires){ 
      
      $update_vip = mysqli_query($connection,"UPDATE users SET vip_active = '0' , vperiod = 'Not subcribe'  WHERE email = '$email'");
    
    }
if($today > $guided_ends){ 
      
      $update_vip = mysqli_query($connection,"UPDATE users SET guided_active = '0' , speriod = 'Not subcribe'  WHERE email = '$email'");
    
    }
    if($today > $basket_ends){ 
      
      $update_vip = mysqli_query($connection,"UPDATE users SET basket = '0' , bperiod = 'Not subcribe'  WHERE email = '$email'");
    
    }
    if($today > $tenins_ends ){ 
      
      $update_vip = mysqli_query($connection,"UPDATE users SET tenins = '0' , tperiod = 'Not subcribe'  WHERE email = '$email'");
    
    }
     if($today > $jack_ends ){ 
      
      $update_vip = mysqli_query($connection,"UPDATE users SET jackpot = '0' , Jperiod = 'Not subcribe'  WHERE email = '$email'");
    
    }
    /*Checks to see if the Super Weekend Plan has expired or not.
    if($today > $fixedExpiryDate){
      
      $update_super = mysqli_query($connection,"UPDATE users SET fixed_plan = '0'  WHERE email = '$email'");

    }*/
    $startr = strtotime($vip_starts);
$endr = strtotime($vip_expires);

$days_between = ceil(abs($endr - $startr) / 86400);

    $date1 = strtotime($active_from); // Register date
    $date2 = strtotime($plan_expired); // Expire date
    $date3 = strtotime($vip_starts); // Clever Active Date
    $date4 = strtotime($vip_expires); // Clever End Date
    
    $todayDate = time();
    $timePast = $todayDate - $date1;
    $cleverTimePast = $todayDate - $date3;
    
    $duration = $date2 - $date1;
    if($todayDate < $date1){
        $completed = 0;
    }elseif($todayDate >= $date2){
        $completed = 100;
    }else{

        $completed  = floor(($timePast/$duration)*100);
    }

    $cleverDuration = $date4 - $date3;
    if($todayDate < $date3){
        $cleverCompleted = 0;
    }elseif($todayDate >= $date4){
        $cleverCompleted = 100;
    }else{
        $cleverCompleted = floor(($cleverTimePast/$cleverDuration)*100);
    }


    $startDate = ((strtotime($today) - strtotime($active_from)) / (60 * 60 * 24));
    $endDate = ((strtotime($plan_expired) - strtotime($active_from)) / (60 * 60 * 24));

    $startCleverDate = ((strtotime($today) - strtotime($vip_starts)) / (60 * 60 * 24));
    $endCleverDate = ((strtotime($vip_expires) - strtotime($vip_starts)) / (60 * 60 * 24));
    
     $startsparkDate = ((strtotime($today) - strtotime($guided_starts)) / (60 * 60 * 24));
    $endsparkDate = ((strtotime($guided_ends) - strtotime($guided_starts)) / (60 * 60 * 24));

?>

<?php

if($active_plan == 0){
 
		                		header("Location: plan?login=1");
		                		exit();    
}
else{
    
		                		header("Location: member?login=1");
		                		exit();
}


?>