<?php
	$connection = mysqli_connect("localhost","preddzzd_accur","Ability_1");
	if(!$connection){
		die("Database connection failed:".mysql_error());
	}

	$db = mysqli_select_db($connection,"preddzzd_accur");
	if(!$db){
		die("Database selection failed:".mysql_error());
	}
?>