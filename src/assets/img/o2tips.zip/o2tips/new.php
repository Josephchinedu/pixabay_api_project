<?php
  ob_start();
  session_start();
  require("config.php");
?>
            
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="author" content="Joseph Chinedu">
	<title>Fixed Matches</title>
	<!-- custom css -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-reboot.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<!-- font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
<body>
	<header>
 		<div id="top-btn">
 		
 		</div>
		<nav class="navbar navbar-expand-lg navbar-dark">
			<div class="container">
				<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsibleNavbar">
					<span class="navbar-toggler-icon"></span>
				</button>
				<a href="index.html" class="nav-brand" id="brand">Accurate Fixed <span id="mt">Match</span></a>
			</div>
		</nav>
	</header>

	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<nav class="navbar navbar-expand-lg navbar-dark" id="menu">
						<div id="collapsibleNavbar" class="collapse navbar-collapse">
							<ul class="navbar-nav m-auto">
									<li class="nav-item">
									<a href="/" class="nav-link">Home</a>
								</li>
							<a href="login.php"><button type="button" class="btn bg-danger text-white btn-sm" style='font-size:18px'>Enter Vip Dashboard</button></a>
		
							</ul>
						</div>
					</nav>
				</div>
			</div>
		</div>
	</section>


	<!-- body content -->
	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div id="main-body">
						<div class="jumbotron" id="about-us">
						    	<?php
                               if($country != "RU"){

                if(isset($_POST["register"])){
                    
                    require("config.php");
                    
                    $fullName = clean($_POST["fullName"]);
                    $email = clean($_POST["email"]);
                    $password = clean($_POST["password"]);
                    $confirmPassword = clean($_POST["confirmPassword"]);
                    $ucountry = clean($_POST["country"]);
                    $phoneNumber = clean($_POST["phoneNumber"]);

                    $query = "SELECT email FROM users WHERE email = '$email'";
                    
                    $result = mysqli_query($connection, $query)
                                or die("Query died: Email");
                    
                    $num = mysqli_num_rows($result);
                    if($num > 0 || $ucountry == "Russian Federation"){
                         $alert="<div class='alert alert-warning' style='background:#b20;color:#fff'>{$email} has already been used.\n\nKindly try again with a new email address</div>";
                    
?>
                       
            
<?php   
                    }elseif($password == $confirmPassword){
                        
                        $blowfish_salt = bin2hex(openssl_random_pseudo_bytes(22));
                        $hash = crypt($password, $blowfish_salt);
                        $encrypted_pass = $hash;

                        $queried = mysqli_query($connection,"INSERT INTO users(fullName,email,password,dateCreated,country,phone_number) VALUES('$fullName','$email','$encrypted_pass',NOW(),'$ucountry','$phoneNumber')");
                        
                   if($queried){
                            
                            $_SESSION['auth'] = "yes";
                            $_SESSION['uname'] = "$uname";

                            //$email = $rows['email'];

                            //$to= $recipients;
                    
                            //$to      = $email; // Send email to our user
                            $subject = 'Welcome to Accuratefixedmatch.com'; // Give the email a subject 
                            $message = "Your Registeration was successful at Accuratefixedmatch.com<br>Kindly Choose a package to complete your registeration.
                            www.Accuratefixedmatch.com/plan
              ";
                            $headers = 'From: Micheal at Accuratefixedmatch.com Welcome <info@Accuratefixedmatch.com>' . "\r\n"; // Set from headers

                            $headers .= 'Reply-To: info@Accuratefixedmatch.com' . "\r\n";
                            //$headers .= 'BCC: ' . implode(', ', $email) . "\r\n";
                            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                         
                          
                            mail($email, $subject, $message, $headers); // Send our email
?>
                            <script>
                                alert("Registration successfully completed.\n\nKindly Login.");
                                location.href = "plan.php";
                            </script>
            
            
<?php   
                        }
                    }

                }

                ?>
                <?php echo $alert ?>
							<div class="col-md-6 offset-md-3">
								<h4 class="text-center">Create Account</h4>
			
								<form class="form" action='' method='post'>
								 <div class="form-group" >
                 
                  <input type="text" class='form-control'  name="fullName"placeholder='Full Name' required="">
                </div>
                <div class="form-group">
              
                  <input type="email"  class='form-control' placeholder='Email Address' name="email" required>
                </div>
                <div class="form-group">
                  
                  <input type="password"  class='form-control' Placeholder='Password'  name="password" required="">
                </div>
                 <div class="form-group">
                  
                  <input type="password"  class='form-control' placeholder='Confirm Password' name="confirmPassword" required="">
                </div>

									<button type='submit' name='register' class="btn bg-danger text-white" style='width:100%'>Create account</button>
								</form>
								 <span class="type--fine-print block">Already have an account?
                                <a href="login">Login into Vip Area</a>
                            </span>
							
							</div>
							<br><br>
								<p> All we do is to help punters make consistent and daily profits from their various wagers and We always fulfill the expectations of admirers of Sport betting, you can start winning today..</p>
						</div>
						    <?php
                
                               }
            ?>
                   
					</div>
				</div>
			</div>
		</div>
	</section>





	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/typed.min.js"></script>
	<script src="js/typed.js"></script>
	<script src="js/main.js"></script>
	 <?php
  function clean($txt){
      
      return trim(htmlentities($txt));
  }
?>
</body>
</html>